import json
import unittest
import boto3
# from confluentMessageProducer import confluentMessageProducer_handler
from time import time
from moto import mock_dynamodb2
from datetime import datetime
import mock
from unittest.mock import Mock, patch
import os
from confluent_kafka import Producer
# import confluentMessageProducer

# DEFAULT_REGION = 'us-west-2'

Item_BaasMessageProducerConfig={
  "Key": {
    "S": "sasl.username"
  },
  "Value": {
    "S": "7XSZKHLV4YEL67V2"
  }
}

Item_BaasMessageProducerConfig1={
  "Key": {
    "S": "KAFKA_BROKER"
  },
  "Value": {
    "S": "7XSZKHLV4YEL67V2"
  }
}

Item_BaasMessageProducerConfig2={
  "Key": {
    "S": "socket.timeout.ms"
  },
  "Value": {
    "S": "100"
  }
}

Item_BaasMessageProducerConfig3={
  "Key": {
    "S": "sasl.mechanisms"
  },
  "Value": {
    "S": "PLAIN"
  }
}

Item_BaasMessageProducerConfig4={
  "Key": {
    "S": "broker.version.fallback"
  },
  "Value": {
    "S": "0.9.0"
  }
}

Item_BaasMessageProducerConfig5={
  "Key": {
    "S": "sasl.password"
  },
  "Value": {
    "S": "j6gi4yNJGWTnIwV2YbJHXACTZp57gnwzy3TQwzzs6p8gev7KZ+4Uzcv/bSq/Jm3Q"
  }
}

Item_BaasMessageProducerConfig6={
  "Key": {
    "S": "message.max.bytes"
  },
  "Value": {
    "S": "1000000000"
  }
}

Item_BaasMessageProducerConfig7={
  "Key": {
    "S": "security.protocol"
  },
  "Value": {
    "S": "SASL_SSL"
  }
}

Item_BaasMessageProducerConfig8={
  "Key": {
    "S": "api.version.request"
  },
  "Value": {
    "S": "true"
  }
}

Item_BaasRequestBatching = {
  "Key": {
    "S": "rowsLimit"
  },
  "Value": {
    "S": "100"
  }
}


Item_BaasRequestBatching1 = {
  "Key": {
    "S": "baasTransactionsCount"
  },
  "Value": {
    "S": "X"
  }
}

Item_BaasRequestQueue = {
  "internalTransactionId": {
    "S": "3c06b273fa694c5387a4fb091a3d39251657008416274"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Queued"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-0-144defce-32b5-4a12-8a82-743da5402b71\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-0-144defce-32b5-4a12-8a82-743da5402b71\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"489512985153\",\"supi\":\"233634288503712\"}]}]},\"header\":{\"spanId\":\"b5141f1a-2eae-4d8e-a870-1f850ccbbe23\",\"channelId\":\"Online\",\"traceId\":\"dc6e4649-e806-4c3c-957d-0fe25561f163\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestTime": {
    "S": "05-07-2022 08:06:56"
  },
  "requestType": {
    "S": "createSubscription"
  },
  "spanId": {
    "S": "b5141f1a-2eae-4d8e-a870-1f850ccbbe23"
  },
  "topicName": {
    "S": "5g.bss.baas.createsubscription.am.1.0"
  },
  "traceId": {
    "S": "dc6e4649-e806-4c3c-957d-0fe25561f163"
  }
}

is_error = None

class TestLambdaFunction(unittest.TestCase):
    @mock.patch.dict(os.environ, {"baasTransactionsCount": "X", "instance": "2", "rowsLimit": "100"}, clear=True)
    @mock_dynamodb2
    def test_confluentMessageProducer_handler(self):
        with patch('confluent_kafka.Producer') as mock_producer:
            boto3.setup_default_session()
            client = boto3.client("dynamodb", region_name='eu-west-2')
            client.create_table(
                TableName="BaasMessageProducerConfig",
                KeySchema=[
                    {"AttributeName": "Key", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "Key", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig1)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig2)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig3)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig4)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig5)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig6)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig7)

            client.put_item(
                TableName="BaasMessageProducerConfig",
                Item=Item_BaasMessageProducerConfig8)

            client.create_table(
                TableName="BaasRequestBatching",
                KeySchema=[
                    {"AttributeName": "Key", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "Key", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BaasRequestBatching",
                Item=Item_BaasRequestBatching)

            client.put_item(
                TableName="BaasRequestBatching",
                Item=Item_BaasRequestBatching1)

            client.create_table(
                TableName="BaasRequestQueue",
                KeySchema=[
                    {"AttributeName": "internalTransactionId", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "internalTransactionId", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BaasRequestQueue",
                Item=Item_BaasRequestQueue)

            client.create_table(
                TableName="BaasTransactionsInflight",
                KeySchema=[
                    {"AttributeName": "internalTransactionId", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "internalTransactionId", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            import confluentMessageProducer
            response = confluentMessageProducer.confluentMessageProducer_handler({}, {})
            self.assertEqual(is_error, response)

if __name__ == '__main__':
    unittest.main()