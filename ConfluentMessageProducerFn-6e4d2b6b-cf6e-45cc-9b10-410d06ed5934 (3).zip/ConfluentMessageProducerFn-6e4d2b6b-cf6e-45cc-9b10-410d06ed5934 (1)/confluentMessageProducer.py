import os
import boto3
import botocore

import urllib3
import time
import json
import logging
import uuid
from datetime import datetime
from time import time
import confluent_kafka
from confluent_kafka import Producer

# Getting ReferenceData information from DynamoDB
BaasMessageProducerConfig_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasMessageProducerConfig')
scan_baas_tbl = BaasMessageProducerConfig_tbl.scan()
Values = scan_baas_tbl['Items']

# Storing the ReferenceData in variables
sasl_username = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'sasl.username'})['Item']['Value']
kafka_broker = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'KAFKA_BROKER'})['Item']['Value']
socket_timeout_ms = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'socket.timeout.ms'})['Item']['Value']
sasl_mechanisms = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'sasl.mechanisms'})['Item']['Value']
broker_version_fallback = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'broker.version.fallback'})['Item'][
    'Value']
sasl_password = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'sasl.password'})['Item']['Value']
message_max_bytes = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'message.max.bytes'})['Item']['Value']
security_protocol = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'security.protocol'})['Item']['Value']
api_version_request = BaasMessageProducerConfig_tbl.get_item(Key={'Key': 'api.version.request'})['Item']['Value']

# Logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Passing ReferenceData variables to Producer function
producer = Producer({
    'bootstrap.servers': kafka_broker,
    'socket.timeout.ms': socket_timeout_ms,
    'api.version.request': api_version_request,
    'broker.version.fallback': broker_version_fallback,
    'message.max.bytes': message_max_bytes,
    'security.protocol': security_protocol,
    'sasl.mechanisms': sasl_mechanisms,
    'sasl.username': sasl_username,
    'sasl.password': sasl_password
})


def confluentMessageProducer_handler(event, context):
    try:

        # Added urllib3 to ignore request warning

        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        count = 0
        inflightCount = 0
        # rowsLimit = os.environ['rowsLimit']
        baasTransactionsCount = os.environ['baasTransactionsCount']
        # datetime operations for internalTransId and requestTime
        # dt = datetime.now()
        # format = "%d-%m-%Y %H:%M:%S"
        # currentTime = dt.strftime(format)   # format datetime using strftime()
        # requestTime = str(currentTime)
        baasRequestQueue_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasRequestQueue')
        BaasTransactionsInflight_count = boto3.resource('dynamodb', region_name="eu-west-2").Table(
            'BaasTransactionsInflight')
        BaasRequestBatching_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasRequestBatching')

        rowsLimit = BaasRequestBatching_tbl.get_item(Key={'Key': 'rowsLimit'})['Item']['Value']
        baasTransactionsCount = BaasRequestBatching_tbl.get_item(Key={'Key': 'baasTransactionsCount'})['Item']['Value']
        print("rowsLimit:::::", rowsLimit)
        print("baasTransactionsCount:::", baasTransactionsCount)

        Inflight_scan_kwargs = None
        if Inflight_scan_kwargs is None:
            Inflight_scan_kwargs = {}
        complete = False
        while not complete:
            try:
                Inflightresponse = BaasTransactionsInflight_count.scan(**Inflight_scan_kwargs)
            except botocore.exceptions.ClientError as error:
                raise Exception('Error quering DB: {}'.format(error))

            next_key = Inflightresponse.get('LastEvaluatedKey')
            Inflight_scan_kwargs['ExclusiveStartKey'] = next_key

            complete = True if next_key is None else False
            print("response items", Inflightresponse['Items'])

            if Inflightresponse is not None and Inflightresponse['Items']:
                print("inside ")
                # Getting each row in to a loop
                for respInflightCount in Inflightresponse['Items']:
                    if set(('channelId', 'internalTransactionId', 'spanId', 'traceId', 'requestType', 'requestPayload',
                            'partnerId')).issubset(respInflightCount.keys()):
                        inflightCount = inflightCount + 1
                    else:
                        BaasTransactionsInflight_count.delete_item(
                            Key={
                                'internalTransactionId': respInflightCount['internalTransactionId']
                            }
                        )

        print("inflightCount:::::", inflightCount)
        print("baasTransactionsCount::::", baasTransactionsCount)
        if baasTransactionsCount != "X" and inflightCount <= int(baasTransactionsCount):
            # function
            trigger_confluentKafka(baasRequestQueue_tbl, rowsLimit, count)
        elif baasTransactionsCount == "X":
            print("elif")
            trigger_confluentKafka(baasRequestQueue_tbl, rowsLimit, count)

        else:
            print("All previous batch still in progress")
    except Exception as error:
        print("Inside Exception")
        logger.exception("message: the error occured due to " + str(error))


def trigger_confluentKafka(baasRequestQueue_tbl, rowsLimit, count):
    scan_kwargs = None
    if scan_kwargs is None:
        scan_kwargs = {}
    complete = False
    while not complete:
        try:
            response = baasRequestQueue_tbl.scan(**scan_kwargs)
        except botocore.exceptions.ClientError as error:
            raise Exception('Error quering DB: {}'.format(error))

        next_key = response.get('LastEvaluatedKey')
        scan_kwargs['ExclusiveStartKey'] = next_key

        complete = True if next_key is None else False

        print("response items", response['Items'])
        # Checking Items in BaasTransaction table
        if response is not None and response['Items']:
            print("inside ")
            # Getting each row in to a loop
            for resp in response['Items']:
                print("in for")

                if count > int(rowsLimit):
                    break

                # update lock status to true in baasRequestQueue table

                lockStatus = \
                    baasRequestQueue_tbl.get_item(Key={'internalTransactionId': resp['internalTransactionId']})[
                        'Item']['lockStatus']

                if lockStatus == 'false':
                    baasRequestQueue_tbl.update_item(
                        Key={'internalTransactionId': resp['internalTransactionId']},
                        UpdateExpression="set lockStatus = :lockStatus",
                        ExpressionAttributeValues={
                            ':lockStatus': 'true'
                        },
                        ReturnValues="UPDATED_NEW"
                    )

                    # Using DynamoDB Client and Resource
                    # dbclient = boto3.client('dynamodb')

                    BaasTransactionsInflight_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table(
                        'BaasTransactionsInflight')

                    if set(('channelId', 'internalTransactionId', 'spanId', 'traceId', 'requestType',
                            'requestPayload', 'partnerId', 'topicName')).issubset(resp.keys()):
                        print("Response Resp::::", resp)
                        internalTransactionId = resp['internalTransactionId']
                        requestPayload = resp['requestPayload']
                        spanId = resp['spanId']
                        traceId = resp['traceId']
                        requestType = resp['requestType']
                        partnerId = resp['partnerId']
                        topicName = resp['topicName']
                        channelId = resp['channelId']
                        partnerRequestTime = resp['requestTime']
                        print("requestPayload from resp::::", requestPayload)
                        requestPayloadinJson = json.loads(resp['requestPayload'])
                        request_header = requestPayloadinJson['header']
                        addInternalTransactionId = {
                            'internalTransactionId': internalTransactionId
                        }
                        addInternalTransactionId.update(request_header)
                        request_header_dict = {'header': addInternalTransactionId}
                        requestPayloadinJson.update(request_header_dict)
                        requestBody = json.dumps(requestPayloadinJson)
                        final_requestBody = json.loads(requestBody)
                        print("final_requestBody::::: ", final_requestBody)

                        # logger from header
                        logger.info(
                            'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: request received [{}]'.format(
                                "1", channelId, internalTransactionId, spanId, traceId, requestType,
                                requestPayload))

                        # Sending the message to kafka topic
                        start_time = int(time() * 1000)
                        error_msg = send_msg_async(final_requestBody, topicName, requestType, channelId,
                                                   internalTransactionId, spanId, traceId)

                        # datetime operations for internalTransId and requestTime
                        dt = datetime.now()
                        format = "%d-%m-%Y %H:%M:%S"
                        currentTime = dt.strftime(format)  # format datetime using strftime()
                        requestTime = str(currentTime)
                        # Insert into baasTransactions table by passing all the required variables
                        updatebaasTrans = BaasTransactionsInflight_tbl.put_item(
                            Item={
                                'internalTransactionId': internalTransactionId,
                                'requestPayload': requestPayload,
                                'requestProcessingStartTime': requestTime,
                                'requestTime': partnerRequestTime,
                                'spanId': spanId,
                                'traceId': traceId,
                                'requestType': requestType,
                                'channelId': channelId,
                                'partnerId': partnerId,
                                'topicName': topicName,
                                'notificationSent': 'false',
                                'overallTransactionStatus': 'Inflight',
                                'lockStatus': 'false'
                            })

                        # Logging after inserting record in BaaSTransaction table
                        logger.info(
                            'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: [{}]'.format(
                                "2", channelId, internalTransactionId, spanId, traceId, requestType,
                                "Request pushed to DynamoDB for processing"))

                        end_time = int(time() * 1000)
                        time_taken = (end_time - start_time) / 1000
                        print("Time taken to complete = %s seconds" % (time_taken))
                        if error_msg is not None:
                            logger.info('"status": "Failure", Error Message: [{}]', str(error_msg))
                        else:
                            logger.info(
                                'internalTransactionId: [{}], channelId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], status: Success'.format(
                                    internalTransactionId, channelId, spanId, traceId, requestType))
                            baasRequestQueue_tbl.delete_item(
                                Key={
                                    'internalTransactionId': resp['internalTransactionId']
                                }
                            )
                        count = count + 1
                        print("count", count)

def delivery_report(err, msg, requestType, channelId, internalTransactionId, spanId, traceId):
    if err is not None:
        print('Message delivery failed: {}'.format(err))
    else:
        print('Message delivered to {} [{}] {}'.format(
            msg.topic(), msg.partition(), msg.offset()))
        # Logging after sending response to Kafka
        logger.info(
            'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: produce msg to kafka topic name [{}], partition [{}], and offset [{}]'.format(
                "3", channelId, internalTransactionId, spanId, traceId, requestType, msg.topic(), msg.partition(),
                msg.offset()))


def send_msg_async(msg, topic, requestType, channelId, internalTransactionId, spanId, traceId):
    print("Sending message")
    try:
        msg_json_str = json.dumps(msg).encode('utf-8');
        producer.produce(
            topic,
            msg_json_str,
            callback=lambda err, original_msg=msg_json_str: delivery_report(err, original_msg
                                                                            , requestType, channelId,
                                                                            internalTransactionId, spanId, traceId),
        )
        producer.flush()

    except Exception as error:
        # return error
        logger.exception("message: the error occured due to " + str(error))