import os
import json
import boto3
from notificationProcessor import notificationProcessor_handler, createDictionary, getTargetSystem, updateLockStatus
from time import time
from moto import mock_dynamodb2
from datetime import datetime
import unittest
import mock
from unittest.mock import Mock, patch
from boto3.dynamodb.conditions import Attr
import notificationProcessor
import requests

DEFAULT_REGION = 'us-west-2'
event = {'Items': [{'partnerId': 'partner1', 'mediationRespTime': '2022-05-19T13:26:37.000Z', 'billingRespStatus': '200', 'requestTime': '19-05-2022 13:26:36', 'mediationRespPayload': '            {"status":"SUCCESS","statusMessage":"Subscriber Creation Flow completed successfully","header":{"spanId":"a24a6ea4-ce75-4665-a070-57453082c256","traceId":"a24a6ea4-ce75-4665-a070-57453082c256","internalTransactionId":"1652966797","partnerId":"partner1","channelId":"Online"},"targetSystem":"Mediation","respUuid":"f251d0cb-e552-490b-adf8-d123e0101681","responseTimestamp":"2022-05-19T13:26:37.000Z"}        ', 'mediationRespStatus': '200', 'lockStatus': 'false', 'ratingRespStatus': '200', 'notificationSent': 'false', 'channelId': 'Online', 'requestPayload': '\n            {"subscriber":{"subscriberId":"test-subscriber-bill-555569","attr":{"MasterAccount":"9099901","BillingAccount":"TW-BillingAccount-dev11","WholesalePlanId":"DISH-Plan002"},"firstName":"Udaya","lastName":"Shanker","activeDt":"2022-05-02T18:00:00Z","subscriptionAddresses":[{"addressLine1":"52-A-1","addressLine2":"St Mount StreetA-1","addressLine3":"St Mount StreetB-1","city":"Ann Arbor","state":"MI","country":"USA","postalCode":"12345","addressType":"AEnd"}],"subscriptions":[{"subscriptionId":"test-subscription-bill-777999","networkName":"DISH","billingCycle":{"billingCycleId":200,"dateOffset":30,"immediateChange":true},"offers":[{"allowanceDetails":[{"allowanceName":"Subscriber - Data Allowance","allowanceReferenceId":"ef5a3a83-ce87-405d-b624-3db85efdb368","allowanceInstanceId":"07f23b4c-bc00-11ec-aa10-0242ac110002","allowanceType":"DDON","externalName":"Data_Allowance","allowanceGrant":5,"unitOfMeasure":"MB","priority":1,"cycleBased":true,"rollOver":true,"allowancePeriodicity":"MONTH","allowancePeriodicityUnits":1,"policies":[{"policyReferenceId":"9e2c7935-46f7-446d-9d5d-bd469886c64f","policyInstanceId":"07f2b07d-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Notify","externalName":"Policy_Data_Notify2","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"NOTIFY","level":75},{"policyReferenceId":"9e2c7935-46f7-446d-9d5d-bd469886c64f","policyInstanceId":"07f2b07e-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Notify","externalName":"Policy_Data_Notify3","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"NOTIFY","level":50},{"policyReferenceId":"9e2c7935-46f7-446d-9d5d-bd469886c64f","policyInstanceId":"07f2b07f-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Notify","externalName":"Policy_Data_Notify1","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"NOTIFY","level":100},{"policyReferenceId":"f995d6f9-12e1-4ca9-9463-bb87454c4c62","policyInstanceId":"07f2b080-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Cap","externalName":"Policy_Data_Cap","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"CAP","level":100}]}]}],"subscriptionAttributes":[{"gpsi":"49229089988","supi":"313122112087788"}]}]},"header":{"spanId":"a24a6ea4-ce75-4665-a070-57453082c256","channelId":"Online","traceId":"a24a6ea4-ce75-4665-a070-57453082c256","partnerId":"partner1"}}\n        ', 'topicName': '5g.bss.baas.createsubscription.am.1.0', 'overallTransactionStatus': '', 'ratingRespPayload': '            {"status":"SUCCESS","statusMessage":"Subscriber Creation Flow completed successfully","subscriberObjectId":"0-1-5-4494","subscriptions":[{"subscriptionObjectId":"0-1-5-4495","deviceObjectId":"0-1-5-4498"}],"header":{"spanId":"a24a6ea4-ce75-4665-a070-57453082c256","traceId":"a24a6ea4-ce75-4665-a070-57453082c256","internalTransactionId":"1652966797","partnerId":"partner1","channelId":"Online"},"targetSystem":"Rating","respUuid":"1bfe8fc5-399a-4790-a119-d5bd8ac087bf","responseTimestamp":"2022-05-19T13:26:38.000Z"}        ', 'ratingRespTime': '2022-05-19T13:26:38.000Z', 'requestType': 'createSubscription', 'internalTransactionId': '1652966797', 'billingRespPayload': '            {"status":"SUCCESS","statusMessage":"Subscriber Creation Flow in Optima completed successfully","subscriptions":[{"serviceInternalId":"37972"}],"header":{"spanId":"a24a6ea4-ce75-4665-a070-57453082c256","traceId":"a24a6ea4-ce75-4665-a070-57453082c256","internalTransactionId":"1652966797","partnerId":"partner1","channelId":"Online"},"targetSystem":"Billing","respUuid":"83911320-7967-431e-b26c-db3c66052e5d","responseTimestamp":"2022-05-19T13:26:39.000Z"}        ', 'billingRespTime': '2022-05-19T13:26:39.000Z', 'spanId': 'a24a6ea4-ce75-4665-a070-57453082c256', 'traceId': 'a24a6ea4-ce75-4665-a070-57453082c256'}], 'Count': 1, 'ScannedCount': 1, 'ResponseMetadata': {'RequestId': 'OO26I55AM8AAU9JLG7L4J2FDU7VV4KQNSO5AEMVJF66Q9ASUAAJG', 'HTTPStatusCode': 200, 'HTTPHeaders': {'server': 'Server', 'date': 'Tue, 24 May 2022 18:14:13 GMT', 'content-type': 'application/x-amz-json-1.0', 'content-length': '5113', 'connection': 'keep-alive', 'x-amzn-requestid': 'OO26I55AM8AAU9JLG7L4J2FDU7VV4KQNSO5AEMVJF66Q9ASUAAJG', 'x-amz-crc32': '187908695'}, 'RetryAttempts': 0}}
targetSysDict = {'workflow': 'createSubscription', 'billing': '200', 'billingRespPayload': '            {"status":"SUCCESS","statusMessage":"Subscriber Creation Flow in Optima completed successfully","subscriptions":[{"serviceInternalId":"37972"}],"header":{"spanId":"a24a6ea4-ce75-4665-a070-57453082c256","traceId":"a24a6ea4-ce75-4665-a070-57453082c256","internalTransactionId":"1652966797","partnerId":"partner1","channelId":"Online"},"targetSystem":"Billing","respUuid":"83911320-7967-431e-b26c-db3c66052e5d","responseTimestamp":"2022-05-19T13:26:39.000Z"}        ', 'rating': '200', 'ratingRespPayload': '            {"status":"SUCCESS","statusMessage":"Subscriber Creation Flow completed successfully","subscriberObjectId":"0-1-5-4494","subscriptions":[{"subscriptionObjectId":"0-1-5-4495","deviceObjectId":"0-1-5-4498"}],"header":{"spanId":"a24a6ea4-ce75-4665-a070-57453082c256","traceId":"a24a6ea4-ce75-4665-a070-57453082c256","internalTransactionId":"1652966797","partnerId":"partner1","channelId":"Online"},"targetSystem":"Rating","respUuid":"1bfe8fc5-399a-4790-a119-d5bd8ac087bf","responseTimestamp":"2022-05-19T13:26:38.000Z"}        ', 'mediation': '200', 'mediationRespPayload': '            {"status":"SUCCESS","statusMessage":"Subscriber Creation Flow completed successfully","header":{"spanId":"a24a6ea4-ce75-4665-a070-57453082c256","traceId":"a24a6ea4-ce75-4665-a070-57453082c256","internalTransactionId":"1652966797","partnerId":"partner1","channelId":"Online"},"targetSystem":"Mediation","respUuid":"f251d0cb-e552-490b-adf8-d123e0101681","responseTimestamp":"2022-05-19T13:26:37.000Z"}        '}
targetSystemsArr = ['billing', 'targetSysDictmediation']
requestType = 'createSubscription'
resp = event['Items'][0]
print(resp)
status = 'false'
Attributes = {'internalTransactionId': '1652966797', 'lockStatus': 'false'}

returnStatement = {'statusCode': 200, 'body': '"Notification process has been completed successfully.."'}

Baasflight_PutItem = {
  "internalTransactionId": {
    "S": "35974a26775e417bac16b62f5c27dc061656413925396"
  },
  "billingRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Subscriber Creation Flow in Optima completed successfully\",\"subscriptions\":[{\"serviceInternalId\":\"1599408\"}],\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"internalTransactionId\":\"35974a26775e417bac16b62f5c27dc061656413925396\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"2b123351-1193-41b1-a9ef-cf5b518ca52b\",\"responseTimestamp\":\"2022-06-28T11:25:01.000Z\"}        "
  },
  "billingRespStatus": {
    "S": "200"
  },
  "billingRespTime": {
    "S": "2022-06-28T11:25:01.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "mediationRespPayload": {
    "S": "            {\"status\":\"Failure\",\"error\":{\"statusCode\":456,\"errorCode\":\"CREATE_FAILED\",\"fields\":[],\"errorMessage\":\"MEDIATION_CREATE_SUBSCRIPTION_FAILED : 404 Not Found: [no body]\"},\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"internalTransactionId\":\"35974a26775e417bac16b62f5c27dc061656413925396\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Mediation\",\"respUuid\":\"561e4149-3d91-40bb-ab0f-88eed5870013\",\"responseTimestamp\":\"2022-06-28T11:16:42.000Z\"}        "
  },
  "mediationRespStatus": {
    "N": "456"
  },
  "mediationRespTime": {
    "S": "2022-06-28T11:16:42.000Z"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"969258902581\",\"supi\":\"543379976654120\"}]}]},\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"channelId\":\"Online\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "06-07-2022 13:37:46"
  },
  "requestTime": {
    "S": "06-07-2022 13:37:40"
  },
  "requestType": {
    "S": "createSubscription"
  },
  "spanId": {
    "S": "b9ebc36b-7efc-4673-b642-f9808472beab"
  },
  "topicName": {
    "S": "5g.bss.baas.createsubscription.am.1.0"
  },
  "traceId": {
    "S": "8f36d9d6-61c3-4c29-8ae6-1934edaafcff"
  }
}

Baasflight_PutItem_1 = {
  "internalTransactionId": {
    "S": "35974a26775e417bac16b62f5c27dc061656413925397"
  },
  "billingRespPayload": {
    "S": "            {\"status\":\"Failure\",\"error\":{\"statusCode\":450,\"errorCode\":\"INVALID_TYPE\",\"fields\":[],\"errorMessage\":\"GET_SERVICE_INTERNALID_FAILED:JMW Get Service Internal Id Failed\"},\"header\":{\"spanId\":\"103a2330-87ff-4b9b-8f38-0dec11e08f54\",\"traceId\":\"2b773db1-2596-4a07-a3dc-609a4c1ab3b8\",\"internalTransactionId\":\"35974a26775e417bac16b62f5c27dc061656413925397\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"10f3d9a5-4e77-44cc-9391-7e8c55ea69e7\",\"responseTimestamp\":\"2022-06-19T13:24:15.000Z\"}     "
  },
  "billingRespStatus": {
    "S": "450"
  },
  "billingRespTime": {
    "S": "2022-06-19T13:24:15.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "mediationRespPayload": {
    "S": "            {\"status\":\"Failure\",\"error\":{\"statusCode\":456,\"errorCode\":\"CREATE_FAILED\",\"fields\":[],\"errorMessage\":\"MEDIATION_CREATE_SUBSCRIPTION_FAILED : 404 Not Found: [no body]\"},\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"internalTransactionId\":\"35974a26775e417bac16b62f5c27dc061656413925397\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Mediation\",\"respUuid\":\"561e4149-3d91-40bb-ab0f-88eed5870013\",\"responseTimestamp\":\"2022-06-28T11:16:42.000Z\"}        "
  },
  "mediationRespStatus": {
    "N": "456"
  },
  "mediationRespTime": {
    "S": "2022-06-28T11:16:42.000Z"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"969258902581\",\"supi\":\"543379976654120\"}]}]},\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"channelId\":\"Online\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "06-07-2022 13:37:42"
  },
  "requestTime": {
    "S": "06-07-2022 13:37:40"
  },
  "requestType": {
    "S": "createSubscription"
  },
  "spanId": {
    "S": "b9ebc36b-7efc-4673-b642-f9808472beab"
  },
  "topicName": {
    "S": "5g.bss.baas.createsubscription.am.1.0"
  },
  "traceId": {
    "S": "8f36d9d6-61c3-4c29-8ae6-1934edaafcff"
  }
}

Baasflight_PutItem_2 = {
  "internalTransactionId": {
    "S": "1f8bdc6aa2184c32a1b3c51beddf5d461655644914379"
  },
  "billingRespPayload": {
    "S": "            {\"status\":\"Failure\",\"error\":{\"statusCode\":450,\"errorCode\":\"INVALID_TYPE\",\"fields\":[],\"errorMessage\":\"GET_SERVICE_INTERNALID_FAILED:JMW Get Service Internal Id Failed\"},\"header\":{\"spanId\":\"103a2330-87ff-4b9b-8f38-0dec11e08f54\",\"traceId\":\"2b773db1-2596-4a07-a3dc-609a4c1ab3b8\",\"internalTransactionId\":\"1f8bdc6aa2184c32a1b3c51beddf5d461655644914379\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"10f3d9a5-4e77-44cc-9391-7e8c55ea69e7\",\"responseTimestamp\":\"2022-06-19T13:24:15.000Z\"}     "
  },
  "billingRespStatus": {
    "S": "450"
  },
  "billingRespTime": {
    "S": "2022-06-19T13:24:15.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "mediationRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Subscriber Creation Flow completed successfully\",\"header\":{\"spanId\":\"103a2330-87ff-4b9b-8f38-0dec11e08f54\",\"traceId\":\"2b773db1-2596-4a07-a3dc-609a4c1ab3b8\",\"internalTransactionId\":\"1f8bdc6aa2184c32a1b3c51beddf5d461655644914379\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Mediation\",\"respUuid\":\"84e95ac6-f256-47af-9a87-2b45995ebbbf\",\"responseTimestamp\":\"2022-06-19T13:24:11.000Z\"}        "
  },
  "mediationRespStatus": {
    "N": "200"
  },
  "mediationRespTime": {
    "S": "2022-06-28T11:16:42.000Z"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"969258902581\",\"supi\":\"543379976654120\"}]}]},\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"channelId\":\"Online\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "06-07-2022 13:37:43"
  },
  "requestTime": {
    "S": "06-07-2022 13:37:40"
  },
  "requestType": {
    "S": "createSubscription"
  },
  "spanId": {
    "S": "b9ebc36b-7efc-4673-b642-f9808472beab"
  },
  "topicName": {
    "S": "5g.bss.baas.createsubscription.am.1.0"
  },
  "traceId": {
    "S": "8f36d9d6-61c3-4c29-8ae6-1934edaafcff"
  }
}

Baasflight_PutItem_3 = {
  "internalTransactionId": {
    "S": "6e085f65c7ea4219ad8c5726d5a80bb81656608042673"
  },
  "billingRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Subscriber Creation Flow in Optima completed successfully\",\"subscriptions\":[{\"serviceInternalId\":\"1639169\"}],\"header\":{\"spanId\":\"d94265f0-608c-4042-9851-97e0b0827d85\",\"traceId\":\"1732d6ad-59d7-48e7-b9ba-3216527b732e\",\"internalTransactionId\":\"6e085f65c7ea4219ad8c5726d5a80bb81656608042673\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"c7767389-ee7c-45de-8580-09e08c50dda9\",\"responseTimestamp\":\"2022-06-30T16:54:26.000Z\"}        "
  },
  "billingRespStatus": {
    "S": "200"
  },
  "billingRespTime": {
    "S": "2022-06-19T13:24:15.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "mediationRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Subscriber Creation Flow completed successfully\",\"header\":{\"spanId\":\"d94265f0-608c-4042-9851-97e0b0827d85\",\"traceId\":\"1732d6ad-59d7-48e7-b9ba-3216527b732e\",\"internalTransactionId\":\"6e085f65c7ea4219ad8c5726d5a80bb81656608042673\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Mediation\",\"respUuid\":\"a9103ecc-520e-4265-9676-4759058cd605\",\"responseTimestamp\":\"2022-06-30T16:54:25.000Z\"}        "
  },
  "mediationRespStatus": {
    "N": "200"
  },
  "mediationRespTime": {
    "S": "2022-06-28T11:16:42.000Z"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"969258902581\",\"supi\":\"543379976654120\"}]}]},\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"channelId\":\"Online\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "06-07-2022 13:37:44"
  },
  "requestTime": {
    "S": "06-07-2022 13:37:40"
  },
  "requestType": {
    "S": "createSubscription"
  },
  "spanId": {
    "S": "b9ebc36b-7efc-4673-b642-f9808472beab"
  },
  "topicName": {
    "S": "5g.bss.baas.createsubscription.am.1.0"
  },
  "traceId": {
    "S": "8f36d9d6-61c3-4c29-8ae6-1934edaafcff"
  }
}

Baasflight_PutItem_4 = {
  "internalTransactionId": {
    "S": "b627cf89ea6a45ff89c19b00549028b21656682068580"
  },
  "billingRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Subscriber Creation Flow in Optima completed successfully\",\"subscriptions\":[{\"serviceInternalId\":\"1639169\"}],\"header\":{\"spanId\":\"d94265f0-608c-4042-9851-97e0b0827d85\",\"traceId\":\"1732d6ad-59d7-48e7-b9ba-3216527b732e\",\"internalTransactionId\":\"b627cf89ea6a45ff89c19b00549028b21656682068580\",\"partnerId\":\"Baas-Cust-001\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"c7767389-ee7c-45de-8580-09e08c50dda9\",\"responseTimestamp\":\"2022-06-30T16:54:26.000Z\"}        "
  },
  "billingRespStatus": {
    "S": "200"
  },
  "billingRespTime": {
    "S": "2022-06-19T13:24:15.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "mediationRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Subscriber Creation Flow completed successfully\",\"header\":{\"spanId\":\"d94265f0-608c-4042-9851-97e0b0827d85\",\"traceId\":\"1732d6ad-59d7-48e7-b9ba-3216527b732e\",\"internalTransactionId\":\"b627cf89ea6a45ff89c19b00549028b21656682068580\",\"partnerId\":\"Baas-Cust-001\",\"channelId\":\"Online\"},\"targetSystem\":\"Mediation\",\"respUuid\":\"a9103ecc-520e-4265-9676-4759058cd605\",\"responseTimestamp\":\"2022-06-30T16:54:25.000Z\"}        "
  },
  "mediationRespStatus": {
    "N": "200"
  },
  "mediationRespTime": {
    "S": "2022-06-28T11:16:42.000Z"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "Baas-Cust-001"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-187-475fca0d-ff4d-43c3-a4f0-d4215c56b258\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"969258902581\",\"supi\":\"543379976654120\"}]}]},\"header\":{\"spanId\":\"b9ebc36b-7efc-4673-b642-f9808472beab\",\"channelId\":\"Online\",\"traceId\":\"8f36d9d6-61c3-4c29-8ae6-1934edaafcff\",\"partnerId\":\"Baas-Cust-001\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "06-07-2022 13:37:45"
  },
  "requestTime": {
    "S": "06-07-2022 13:37:40"
  },
  "requestType": {
    "S": "createSubscription"
  },
  "spanId": {
    "S": "b9ebc36b-7efc-4673-b642-f9808472beab"
  },
  "topicName": {
    "S": "5g.bss.baas.createsubscription.am.1.0"
  },
  "traceId": {
    "S": "8f36d9d6-61c3-4c29-8ae6-1934edaafcff"
  }
}

Baasflight_PutItem_5 = {
  "internalTransactionId": {
    "S": "753f2b3225864b558a608bd5797905671657089965785"
  },
  "billingRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Subscriber Creation Flow in Optima completed successfully\",\"subscriptions\":[{\"serviceInternalId\":\"1937711\"}],\"header\":{\"spanId\":\"bec07fd8-e8c0-43ed-ae32-f95c70988c43\",\"traceId\":\"f4e23aaf-17e7-4fc6-98e1-77260e3f33ea\",\"internalTransactionId\":\"753f2b3225864b558a608bd5797905671657089965785\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"6252fca4-8c9c-4d82-9205-19a47ef82c13\",\"responseTimestamp\":\"2022-07-06T06:46:25.000Z\"}        "
  },
  "billingRespStatus": {
    "S": "200"
  },
  "billingRespTime": {
    "S": "2022-07-06T06:46:25.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"418584115949\",\"supi\":\"440747594155645\"}]}]},\"header\":{\"spanId\":\"bec07fd8-e8c0-43ed-ae32-f95c70988c43\",\"channelId\":\"Online\",\"traceId\":\"f4e23aaf-17e7-4fc6-98e1-77260e3f33ea\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "28-06-2022 11:16:41"
  },
  "requestTime": {
    "S": "28-06-2022 11:16:40"
  },
  "requestType": {
    "S": "createSubscription"
  },
  "spanId": {
    "S": "bec07fd8-e8c0-43ed-ae32-f95c70988c43"
  },
  "topicName": {
    "S": "5g.bss.baas.createsubscription.am.1.0"
  },
  "traceId": {
    "S": "f4e23aaf-17e7-4fc6-98e1-77260e3f33ea"
  }
}

Baasflight_PutItem_6 = {
  "internalTransactionId": {
    "S": "df3f1c8d001a4cefb693fa83052aee3d1657106114829"
  },
  "billingRespPayload": {
    "S": "            {\"status\":\"SUCCESS\",\"statusMessage\":\"Posting a payment operation successful!\",\"paymentProfileId\":10204003,\"paymentId\":4071,\"header\":{\"spanId\":\"a24a6ea4-ce75-4665-a070-57453082c256\",\"traceId\":\"a24a6ea4-ce75-4665-a070-57453082c256\",\"internalTransactionId\":\"df3f1c8d001a4cefb693fa83052aee3d1657106114829\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"dab02d00-dad7-4cfb-90fd-9be318cec623\",\"responseTimestamp\":\"2022-07-06T11:15:22.000Z\"}        "
  },
  "billingRespStatus": {
    "S": "200"
  },
  "billingRespTime": {
    "S": "2022-07-08T06:46:25.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"418584115949\",\"supi\":\"440747594155645\"}]}]},\"header\":{\"spanId\":\"bec07fd8-e8c0-43ed-ae32-f95c70988c43\",\"channelId\":\"Online\",\"traceId\":\"f4e23aaf-17e7-4fc6-98e1-77260e3f33ea\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "08-07-2022 11:15:21"
  },
  "requestTime": {
    "S": "08-07-2022 11:15:21"
  },
  "requestType": {
    "S": "createPayment"
  },
  "spanId": {
    "S": "bec07fd8-e8c0-43ed-ae32-f95c70988c43"
  },
  "topicName": {
    "S": "5g.bss.baas.createPayment.am.1.0"
  },
  "traceId": {
    "S": "f4e23aaf-17e7-4fc6-98e1-77260e3f33ea"
  }
}

Baasflight_PutItem_7 = {
  "internalTransactionId": {
    "S": "969506578c6045228042871314d469971657190251582"
  },
  "billingRespPayload": {
    "S": "            {\"billingAccountNumber\":\"BillingAccountNumber\",\"companyName\":\"Some Company Name\",\"invoiceNumber\":0,\"invoiceDate\":\"2022-01-01T00:00:00.00Z\",\"fileName\":\"BILL_0_254480_3_58.csv\",\"bucketName\":\"s3://invoice-jnl-dev/Invoices-Details/\",\"status\":\"SUCCESS\",\"header\":{\"spanId\":\"a24a6ea4-ce75-4665-a070-57453082c256\",\"traceId\":\"a24a6ea4-ce75-4665-a070-57453082c256\",\"internalTransactionId\":\"969506578c6045228042871314d469971657190251582\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"f7b562b8-1c1b-4de8-8ff1-a7f370007b23\",\"responseTimestamp\":\"2022-07-07T10:37:54.000Z\"}        "
  },
  "billingRespStatus": {
    "S": "200"
  },
  "billingRespTime": {
    "S": "2022-07-08T06:46:25.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"418584115949\",\"supi\":\"440747594155645\"}]}]},\"header\":{\"spanId\":\"bec07fd8-e8c0-43ed-ae32-f95c70988c43\",\"channelId\":\"Online\",\"traceId\":\"f4e23aaf-17e7-4fc6-98e1-77260e3f33ea\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "08-07-2022 11:15:21"
  },
  "requestTime": {
    "S": "08-07-2022 11:15:21"
  },
  "requestType": {
    "S": "createProformaInvoice"
  },
  "spanId": {
    "S": "bec07fd8-e8c0-43ed-ae32-f95c70988c43"
  },
  "topicName": {
    "S": "5g.bss.baas.createProformaInvoice.am.1.0"
  },
  "traceId": {
    "S": "f4e23aaf-17e7-4fc6-98e1-77260e3f33ea"
  }
}

Baasflight_PutItem_8 = {
  "internalTransactionId": {
    "S": "969506578c6045228042871314d469971657190251584"
  },
  "billingRespPayload": {
    "S": "            {\"billingAccountNumber\":\"BillingAccountNumber\",\"companyName\":\"Some Company Name\",\"invoiceNumber\":0,\"invoiceDate\":\"2022-01-01T00:00:00.00Z\",\"fileName\":\"BILL_0_254480_3_58.csv\",\"bucketName\":\"s3://invoice-jnl-dev/Invoices-Details/\",\"status\":\"SUCCESS\",\"header\":{\"spanId\":\"a24a6ea4-ce75-4665-a070-57453082c256\",\"traceId\":\"a24a6ea4-ce75-4665-a070-57453082c256\",\"internalTransactionId\":\"969506578c6045228042871314d469971657190251584\",\"partnerId\":\"partner1\",\"channelId\":\"Online\"},\"targetSystem\":\"Billing\",\"respUuid\":\"f7b562b8-1c1b-4de8-8ff1-a7f370007b23\",\"responseTimestamp\":\"2022-07-07T10:37:54.000Z\"}        "
  },
  "billingRespStatus": {
    "S": "8000"
  },
  "billingRespTime": {
    "S": "2022-07-08T06:46:25.000Z"
  },
  "channelId": {
    "S": "Online"
  },
  "lockStatus": {
    "S": "false"
  },
  "notificationSent": {
    "S": "false"
  },
  "overallTransactionStatus": {
    "S": "Inflight"
  },
  "partnerId": {
    "S": "partner1"
  },
  "requestPayload": {
    "S": "\n            {\"subscriber\":{\"subscriberId\":\"ck-Subscriber-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"attr\":{\"MasterAccount\":\"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"BillingAccount\":\"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5\",\"WholesalePlanId\":\"DISH-Plan002\"},\"firstName\":\"Udaya\",\"lastName\":\"Shanker\",\"activeDt\":\"2022-05-02T18:00:00Z\",\"subscriptionAddresses\":[{\"addressLine1\":\"52-A-1\",\"addressLine2\":\"St Mount StreetA-1\",\"addressLine3\":\"St Mount StreetB-1\",\"city\":\"Ann Arbor\",\"state\":\"MI\",\"country\":\"USA\",\"postalCode\":\"12345\",\"addressType\":\"AEnd\"}],\"subscriptions\":[{\"subscriptionId\":\"ck-SubscriptionId-0-17749b25-7bb8-460d-8c57-dc8678bc0bea\",\"networkName\":\"DISH\",\"billingCycle\":{\"billingCycleId\":200,\"dateOffset\":30,\"immediateChange\":true},\"offers\":[{\"offerId\":\"123\",\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"ef5a3a83-ce87-405d-b624-3db85efdb368\",\"allowanceInstanceId\":\"07f23b4c-bc00-11ec-aa10-0242ac110002\",\"allowanceType\":\"DDON\",\"externalName\":\"Data_Allowance\",\"allowanceGrant\":5,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":true,\"rollOver\":true,\"allowancePeriodicity\":\"MONTH\",\"allowancePeriodicityUnits\":1,\"policies\":[{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07d-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify2\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":75},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07e-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify3\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":50},{\"policyReferenceId\":\"9e2c7935-46f7-446d-9d5d-bd469886c64f\",\"policyInstanceId\":\"07f2b07f-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Notify\",\"externalName\":\"Policy_Data_Notify1\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"NOTIFY\",\"level\":100},{\"policyReferenceId\":\"f995d6f9-12e1-4ca9-9463-bb87454c4c62\",\"policyInstanceId\":\"07f2b080-bc00-11ec-aa10-0242ac110002\",\"policyName\":\"Subscriber - Policy Cap\",\"externalName\":\"Policy_Data_Cap\",\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\",\"action\":\"CAP\",\"level\":100}]}]},{\"offerId\":\"123\",\"rate\":2000,\"allowanceDetails\":[{\"allowanceName\":\"Subscriber - Data Allowance\",\"allowanceReferenceId\":\"allowance-ref-id-1\",\"allowanceInstanceId\":\"allowance-instance-id-1\",\"allowanceType\":\"DDON\",\"externalName\":\"One Time Data Bucket (Expires)\",\"allowanceGrant\":100,\"unitOfMeasure\":\"MB\",\"priority\":1,\"cycleBased\":false,\"rollOver\":false,\"allowancePeriodicityUnits\":1,\"allowancePeriodicity\":\"MONTH\",\"policies\":[{\"policyReferenceId\":\"policy-ref-id-1\",\"policyInstanceId\":\"policy-inst-id-1\",\"policyName\":\"policy-name-1\",\"externalName\":\"Notification 1st Level\",\"action\":\"NOTIFY\",\"level\":33,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-2\",\"policyInstanceId\":\"policy-inst-id-2\",\"policyName\":\"policy-name-2\",\"externalName\":\"Notification 2nd Level\",\"action\":\"NOTIFY\",\"level\":67,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-3\",\"policyInstanceId\":\"policy-inst-id-3\",\"policyName\":\"policy-name-3\",\"externalName\":\"Notification 3rd Level\",\"action\":\"NOTIFY\",\"level\":90,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"},{\"policyReferenceId\":\"policy-ref-id-4\",\"policyInstanceId\":\"policy-inst-id-4\",\"policyName\":\"policy-name-4\",\"externalName\":\"Cap Level\",\"action\":\"CAP\",\"level\":100,\"unitOfMeasure\":\"MB\",\"measurementType\":\"PERCENTAGE\"}]}]}],\"subscriptionAttributes\":[{\"gpsi\":\"418584115949\",\"supi\":\"440747594155645\"}]}]},\"header\":{\"spanId\":\"bec07fd8-e8c0-43ed-ae32-f95c70988c43\",\"channelId\":\"Online\",\"traceId\":\"f4e23aaf-17e7-4fc6-98e1-77260e3f33ea\",\"partnerId\":\"partner1\"}}\n        "
  },
  "requestProcessingStartTime": {
    "S": "08-07-2022 11:15:21"
  },
  "requestTime": {
    "S": "08-07-2022 11:15:21"
  },
  "requestType": {
    "S": "createProformaInvoice"
  },
  "spanId": {
    "S": "bec07fd8-e8c0-43ed-ae32-f95c70988c43"
  },
  "topicName": {
    "S": "5g.bss.baas.createProformaInvoice.am.1.0"
  },
  "traceId": {
    "S": "f4e23aaf-17e7-4fc6-98e1-77260e3f33ea"
  }
}

item_BaasTargetSystems = {
  "workflow": {
    "S": "createSubscription"
  },
  "targetSystems": {
    "S": "billing,mediation"
  }
}

item_BaasTargetSystems_1 = {
  "workflow": {
    "S": "createPayment"
  },
  "targetSystems": {
    "S": "billing"
  }
}

item_BaasTargetSystems_2 = {
  "workflow": {
    "S": "createProformaInvoice"
  },
  "targetSystems": {
    "S": "billing"
  }
}

item_respDecisionTbl = {
  "id": {
    "S": "createSubscription_200_456_NA"
  },
  "billing": {
    "S": "200"
  },
  "mediation": {
    "S": "456"
  },
  "rating": {
    "S": "NA"
  },
  "respKey": {
    "S": "createSubscription_200_456_NA"
  },
  "workflow": {
    "S": "createSubscription"
  }
}

item_respDecisionTbl_1 = {
  "id": {
    "S": "createSubscription_450_456_NA"
  },
  "billing": {
    "S": "450"
  },
  "mediation": {
    "S": "456"
  },
  "rating": {
    "S": "NA"
  },
  "respKey": {
    "S": "createSubscription_450_456_NA"
  },
  "workflow": {
    "S": "createSubscription"
  }
}

item_respDecisionTbl_2 = {
  "id": {
    "S": "createSubscription_450_200_NA"
  },
  "billing": {
    "S": "450"
  },
  "mediation": {
    "S": "200"
  },
  "rating": {
    "S": "NA"
  },
  "respKey": {
    "S": "createSubscription_450_200_NA"
  },
  "workflow": {
    "S": "createSubscription"
  }
}

item_respDecisionTbl_3 = {
  "id": {
    "S": "createSubscription_200_200_NA"
  },
  "billing": {
    "S": "200"
  },
  "mediation": {
    "S": "200"
  },
  "rating": {
    "S": "NA"
  },
  "respKey": {
    "S": "createSubscription_200_200_NA"
  },
  "workflow": {
    "S": "createSubscription"
  }
}

item_respDecisionTbl_4 = {
  "id": {
    "S": "createSubscription_DEF_DEF_DEF"
  },
  "billing": {
    "S": "DEF"
  },
  "mediation": {
    "S": "DEF"
  },
  "rating": {
    "S": "DEF"
  },
  "respKey": {
    "S": "createSubscription_DEF_DEF_DEF"
  },
  "workflow": {
    "S": "createSubscription"
  }
}

item_respDecisionTbl_5 = {
  "id": {
    "S": "createPayment_200_NA_NA"
  },
  "billing": {
    "S": "200"
  },
  "mediation": {
    "S": "NA"
  },
  "rating": {
    "S": "NA"
  },
  "respKey": {
    "S": "createPayment_200_NA_NA"
  },
  "workflow": {
    "S": "createPayment"
  }
}

item_respDecisionTbl_6 = {
  "id": {
    "S": "createProformaInvoice_200_NA_NA"
  },
  "billing": {
    "S": "200"
  },
  "mediation": {
    "S": "NA"
  },
  "rating": {
    "S": "NA"
  },
  "respKey": {
    "S": "createProformaInvoice_200_NA_NA"
  },
  "workflow": {
    "S": "createProformaInvoice"
  }
}



item_callBackConfig = {
  "partnerId": {
    "S": "partner1"
  },
  "endpoint": {
    "S": "https://dev.api.dishcloud.io/baas-notification-logging"
  }
}

item_responseTemplate = {
  "respKey": {
    "S": "createSubscription_200_456_NA"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createSubscription\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Failure\",\"errorCode\": \"BAAS_INVLD_REQ\",\"errorMessage\": \"Invalid Request\",\"errorDetails\": \"\"}}"
  }
}

item_responseTemplate_1 = {
  "respKey": {
    "S": "createSubscription_450_456_NA"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createSubscription\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Failure\",\"errorCode\": \"BAAS_INVLD_REQ\",\"errorMessage\": \"Invalid Request\",\"errorDetails\": \"\"}}"
  }
}

item_responseTemplate_2 = {
  "respKey": {
    "S": "createSubscription_450_200_NA"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createSubscription\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Failure\",\"errorCode\": \"BAAS_INVLD_REQ\",\"errorMessage\": \"Invalid Request\",\"errorDetails\": \"\"}}"
  }
}

item_responseTemplate_3 = {
  "respKey": {
    "S": "createSubscription_200_200_NA"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createSubscription\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Success\"}}"
  }
}

item_responseTemplate_4 = {
  "respKey": {
    "S": "createSubscription_DEF_DEF_DEF"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createSubscription\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Failure\",\"errorCode\": \"BAAS_PROCESS_ERROR\",\"errorMessage\": \"Request is failed to process one or more underlined systems. Please reach out helpdesk to fix and process the request\",\"errorDetails\": \"\"}}"
  }
}

item_responseTemplate_5 = {
  "respKey": {
    "S": "createPayment_200_NA_NA"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createPayment\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Success\",\"paymentProfileId\": \"\",\"paymentId\": \"\"}}"
  }
}

item_responseTemplate_6 = {
  "respKey": {
    "S": "createProformaInvoice_200_NA_NA"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createProformaInvoice\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Success\",\"billingAccountNumber\": \"\",\"companyName\": \"\",\"invoiceNumber\": \"\",\"invoiceDate\": \"\",\"fileName\": \"\",\"bucketName\": \"\"}}"
  }
}

item_responseTemplate_7 = {
  "respKey": {
    "S": "createProformaInvoice_DEF_DEF_DEF"
  },
  "respTemplate": {
    "S": "{\"header\":{\"spanId\": \"\",\"traceId\": \"\",\"channelId\": \"\",\"internalTransactionId\": \"\"},\"messageType\": \"createProformaInvoice\",\"message\": {\"requestSubmittedOn\": \"\",\"requestProcessedOn\": \"\",\"status\": \"Failure\",\"errorCode\": \"BAAS_PROCESS_ERROR\",\"errorMessage\": \"Request is failed to process one or more underlined systems. Please reach out helpdesk to fix and process the request\",\"errorDetails\": \"\"}}"
  }
}

item_baastimeout = {
  "workflow": {
    "S": "createSubscription"
  },
  "billingResponseTime": {
    "S": "30000"
  },
  "mediationResponseTime": {
    "S": "30000"
  }
}

item_baastimeout_1 = {
  "workflow": {
    "S": "createPayment"
  },
  "billingResponseTime": {
    "S": "30000"
  }
}

item_baastimeout_2 = {
  "workflow": {
    "S": "createProformaInvoice"
  },
  "billingResponseTime": {
    "S": "30000"
  }
}

class TestLambdaFunction(unittest.TestCase):

    @mock.patch.dict(os.environ, {"rowsLimit": "300", "falloutTimePeriod": "0"}, clear=True)
    @mock_dynamodb2
    def test_notificationProcessor_handler(self):
        with patch('requests.post') as mock_request:
            boto3.setup_default_session()
            client = boto3.client("dynamodb", region_name='eu-west-2')
            client.create_table(
                TableName="BaasTransactionsInflight",
                KeySchema=[
                    {"AttributeName": "internalTransactionId", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "internalTransactionId", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BaasTransactionsInflight",
                Item=Baasflight_PutItem)

            client.put_item(
                TableName="BaasTransactionsInflight",
                Item=Baasflight_PutItem_1)

            client.put_item(
                TableName="BaasTransactionsInflight",
                Item=Baasflight_PutItem_2)

            client.put_item(
                TableName="BaasTransactionsInflight",
                Item=Baasflight_PutItem_3)

            client.put_item(
                TableName="BaasTransactionsInflight",
                Item=Baasflight_PutItem_4)

            client.put_item(
              TableName="BaasTransactionsInflight",
              Item=Baasflight_PutItem_5)

            client.put_item(
              TableName="BaasTransactionsInflight",
              Item=Baasflight_PutItem_6)

            client.put_item(
              TableName="BaasTransactionsInflight",
              Item=Baasflight_PutItem_7)

            client.put_item(
              TableName="BaasTransactionsInflight",
              Item=Baasflight_PutItem_8)

            client.create_table(
                TableName="BaasTransactions",
                KeySchema=[
                    {"AttributeName": "internalTransactionId", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "internalTransactionId", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )

            client.create_table(
              TableName="baasTimeoutConfig",
              KeySchema=[
                {"AttributeName": "workflow", "KeyType": "HASH"},
              ],
              AttributeDefinitions=[
                {"AttributeName": "workflow", "AttributeType": "S"},
              ],
              ProvisionedThroughput={
                'ReadCapacityUnits': 50,
                'WriteCapacityUnits': 50
              }
            )
            client.put_item(
              TableName="baasTimeoutConfig",
              Item=item_baastimeout)

            client.put_item(
              TableName="baasTimeoutConfig",
              Item=item_baastimeout_1)

            client.put_item(
              TableName="baasTimeoutConfig",
              Item=item_baastimeout_2)

            client.create_table(
                TableName="BaasResponseTemplate",
                KeySchema=[
                    {"AttributeName": "respKey", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "respKey", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BaasResponseTemplate",
                Item=item_responseTemplate)

            client.put_item(
                TableName="BaasResponseTemplate",
                Item=item_responseTemplate_1)

            client.put_item(
                TableName="BaasResponseTemplate",
                Item=item_responseTemplate_2)

            client.put_item(
                TableName="BaasResponseTemplate",
                Item=item_responseTemplate_3)

            client.put_item(
              TableName="BaasResponseTemplate",
              Item=item_responseTemplate_4)

            client.put_item(
              TableName="BaasResponseTemplate",
              Item=item_responseTemplate_5)

            client.put_item(
              TableName="BaasResponseTemplate",
              Item=item_responseTemplate_6)

            client.put_item(
              TableName="BaasResponseTemplate",
              Item=item_responseTemplate_7)

            client.create_table(
                TableName="BaasCallbackConfig",
                KeySchema=[
                    {"AttributeName": "partnerId", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "partnerId", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BaasCallbackConfig",
                Item=item_callBackConfig)

            client.create_table(
                TableName="BaasResponseDecisionTable",
                KeySchema=[
                    {"AttributeName": "id", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "id", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BaasResponseDecisionTable",
                Item=item_respDecisionTbl)

            client.put_item(
                TableName="BaasResponseDecisionTable",
                Item=item_respDecisionTbl_1)

            client.put_item(
                TableName="BaasResponseDecisionTable",
                Item=item_respDecisionTbl_2)

            client.put_item(
                TableName="BaasResponseDecisionTable",
                Item=item_respDecisionTbl_3)

            client.put_item(
              TableName="BaasResponseDecisionTable",
              Item=item_respDecisionTbl_4)

            client.put_item(
              TableName="BaasResponseDecisionTable",
              Item=item_respDecisionTbl_5)

            client.put_item(
              TableName="BaasResponseDecisionTable",
              Item=item_respDecisionTbl_6)

            client.create_table(
                TableName="BAASTargetSystems",
                KeySchema=[
                    {"AttributeName": "workflow", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "workflow", "AttributeType": "S"},
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 50,
                    'WriteCapacityUnits': 50
                }
            )
            client.put_item(
                TableName="BAASTargetSystems",
                Item=item_BaasTargetSystems)

            client.put_item(
              TableName="BAASTargetSystems",
              Item=item_BaasTargetSystems_1)

            client.put_item(
              TableName="BAASTargetSystems",
              Item=item_BaasTargetSystems_2)
            mock_request.return_value.status_code = 200
            response = notificationProcessor.notificationProcessor_handler({}, {})
            print("final response:::::", response)
            self.assertEqual(returnStatement, response)

if __name__ == '__main__':
    unittest.main()



