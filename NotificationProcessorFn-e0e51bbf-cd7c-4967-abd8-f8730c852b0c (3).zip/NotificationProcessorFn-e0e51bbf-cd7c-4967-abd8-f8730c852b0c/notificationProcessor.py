import json
import boto3
import os
from boto3.dynamodb.conditions import Key, And, Attr
from datetime import datetime
from functools import reduce
import requests
import urllib3
import logging
import botocore

def notificationProcessor_handler(event, context):
    # Declaring variables

    falloutTimePeriod = os.environ['falloutTimePeriod']
    rowsLimit = os.environ['rowsLimit']
    BaasTransactionsInflight_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasTransactionsInflight')
    # BaasTransactions_success_tbl =  boto3.resource('dynamodb').Table('BaasTransactionsSuccess')
    # BaasTransactions_failure_tbl =  boto3.resource('dynamodb').Table('BaasTransactionsFailure')
    # BaasTransactions_rejected_tbl =  boto3.resource('dynamodb').Table('BaasTransactionsRejected')
    BaasTransactions_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasTransactions')

    BaasCallbackConfig_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasCallbackConfig')
    BAASResponseTemplate_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasResponseTemplate')
    BAASResponseDecissionTable_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('BaasResponseDecisionTable')
    BaasTimeoutConfigTable_tbl = boto3.resource('dynamodb', region_name="eu-west-2").Table('baasTimeoutConfig')
    count = 0
    # Logging
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # Main try catch block
    try:

        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        notificationSentStatus = 'false'
        isFallout = 'false'

        scan_kwargs = None
        if scan_kwargs is None:
            scan_kwargs = {}
        complete = False
        while not complete:
            try:
                response = BaasTransactionsInflight_tbl.scan(**scan_kwargs,
                                                             FilterExpression=Attr('notificationSent').eq(
                                                                 notificationSentStatus))
            except botocore.exceptions.ClientError as error:
                raise Exception('Error quering DB: {}'.format(error))

            next_key = response.get('LastEvaluatedKey')
            scan_kwargs['ExclusiveStartKey'] = next_key

            complete = True if next_key is None else False

            print("response items", response['Items'])
            # Checking Items in BaasTransactionsInflight table
            if response is not None and response['Items']:
                print("inside ")
                # Getting each row in to a loop
                for resp in response['Items']:
                    print("in for")
                    if count > int(rowsLimit):
                        break
                    print("after break")
                    header = {}
                    message = {}
                    sendVar = 'false'
                    print("Record coming from BaasTransactionsInflight_tbl: ", resp)

                    # logger baas transaction table
                    if set(('channelId', 'internalTransactionId', 'spanId', 'traceId', 'requestType')).issubset(
                            resp.keys()):
                        logger.info(
                            'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], tratraceIdceId: [{}], requestType: [{}], message: got candidate row for notification [{}]'.format(
                                "6", resp['channelId'], resp['internalTransactionId'], resp['spanId'], resp['traceId'],
                                resp['requestType'], resp))

                        lockStatus = BaasTransactionsInflight_tbl.get_item(
                            Key={'internalTransactionId': resp['internalTransactionId']})['Item']['lockStatus']
                        notificationSent = BaasTransactionsInflight_tbl.get_item(
                            Key={'internalTransactionId': resp['internalTransactionId']})['Item']['notificationSent']
                        print("lockStatus is: ", lockStatus)
                        if lockStatus == 'false' and notificationSent == 'false':
                            try:
                                # Updating lock status to true, to block this record
                                updateLockStatus(resp, 'true', BaasTransactionsInflight_tbl)
                                if resp['internalTransactionId']:
                                    resp_internalTransactionId = resp['internalTransactionId']
                                    requestTime = BaasTransactionsInflight_tbl.get_item(
                                        Key={'internalTransactionId': resp_internalTransactionId})['Item'][
                                        'requestProcessingStartTime']
                                    billingResponseFalloutTime = None
                                    mediationResponseFalloutTime = None
                                    ResponseFalloutTimeType = BaasTimeoutConfigTable_tbl.get_item(
                                        Key={'workflow': resp['requestType']})
                                    if 'Item' in ResponseFalloutTimeType:

                                        if 'billingResponseTime' in ResponseFalloutTimeType['Item']:
                                            billingResponseFalloutTime = \
                                            BaasTimeoutConfigTable_tbl.get_item(Key={'workflow': resp['requestType']})[
                                                'Item']['billingResponseTime']
                                        if 'mediationResponseTime' in ResponseFalloutTimeType['Item']:
                                            mediationResponseFalloutTime = \
                                            BaasTimeoutConfigTable_tbl.get_item(Key={'workflow': resp['requestType']})[
                                                'Item']['mediationResponseTime']

                                    dt = datetime.now()
                                    format = "%d-%m-%Y %H:%M:%S"
                                    currentTime = dt.strftime(format)

                                    time_left = datetime.strptime(currentTime, format) - datetime.strptime(requestTime,
                                                                                                           format)
                                    print("current_time", currentTime, "requestTime", requestTime)
                                    print("total_seconds", time_left.total_seconds())
                                    print("billingResponseFalloutTime_withoutFloat", billingResponseFalloutTime,
                                          "mediationResponseFalloutTime", mediationResponseFalloutTime)
                                    # if time_left.total_seconds() > float(falloutTimePeriod):
                                    if billingResponseFalloutTime and mediationResponseFalloutTime:
                                        print("inside billingResponseFalloutTime and mediationResponseFalloutTime")
                                        if time_left.total_seconds() > float(
                                                billingResponseFalloutTime) and time_left.total_seconds() > float(
                                                mediationResponseFalloutTime):
                                            print("isFallout", isFallout)
                                            isFallout = 'true'
                                    elif billingResponseFalloutTime:
                                        print("inside elif billingResponseFalloutTime")
                                        if time_left.total_seconds() > float(billingResponseFalloutTime):
                                            print("isFallout", isFallout)
                                            isFallout = 'true'


                                    if resp['requestType']:
                                        requestType = resp['requestType']
                                        print("before targetSystemsArr")
                                        targetSystemsArr = getTargetSystem(requestType)
                                        print("after targetSystemsArr")
                                        Dict = createDictionary(targetSystemsArr, requestType, resp)

                                        # Logger for target systems
                                        logger.info(
                                            'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: [{}]'.format(
                                                "7", resp['channelId'], resp['internalTransactionId'], resp['spanId'],
                                                resp['traceId'], resp['requestType'],
                                                'success from all the target systems.'))

                                        # Initializing error target systems variables
                                        billingErrMsg = None
                                        ratingErrMsg = None
                                        mediationErrMsg = None
                                        concatinatedRespStr = None


                                        if not None in Dict.values():

                                            if 'billingRespPayload' in Dict and Dict[
                                                'billingRespPayload'] is not None and Dict['billingRespPayload'] != '':
                                                billingRespPayload = json.loads(Dict['billingRespPayload'])
                                                if 'error' in billingRespPayload and 'errorMessage' in \
                                                        billingRespPayload['error']:
                                                    billingErrMsg = billingRespPayload['error']['errorMessage']

                                            if 'ratingRespPayload' in Dict and Dict['ratingRespPayload'] is not None and \
                                                    Dict['ratingRespPayload'] != '':
                                                ratingRespPayload = json.loads(Dict['ratingRespPayload'])
                                                if 'error' in ratingRespPayload and 'errorMessage' in ratingRespPayload[
                                                    'error']:
                                                    ratingErrMsg = ratingRespPayload['error']['errorMessage']

                                            if 'mediationRespPayload' in Dict and Dict[
                                                'mediationRespPayload'] is not None and Dict[
                                                'mediationRespPayload'] != '':
                                                mediationRespPayload = json.loads(Dict['mediationRespPayload'])
                                                if 'error' in mediationRespPayload and 'errorMessage' in \
                                                        mediationRespPayload['error']:
                                                    mediationErrMsg = mediationRespPayload['error']['errorMessage']
                                            if billingErrMsg is not None and billingErrMsg != '':
                                                concatinatedRespStr = billingErrMsg

                                            if ratingErrMsg is not None and ratingErrMsg != '':
                                                if concatinatedRespStr is not None and concatinatedRespStr != '':
                                                    concatinatedRespStr = concatinatedRespStr + "|" + ratingErrMsg

                                                else:
                                                    concatinatedRespStr = ratingErrMsg
                                            if mediationErrMsg is not None and mediationErrMsg != '':
                                                if concatinatedRespStr is not None and concatinatedRespStr != '':
                                                    concatinatedRespStr = concatinatedRespStr + "|" + mediationErrMsg
                                                else:
                                                    concatinatedRespStr = mediationErrMsg
                                            print('concatinatedRespStr::::', concatinatedRespStr)

                                            # logger for concatinatedRespStr
                                            logger.info(
                                                'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: concatinated error message [{}]'.format(
                                                    "8", resp['channelId'], resp['internalTransactionId'],
                                                    resp['spanId'], resp['traceId'], resp['requestType'],
                                                    concatinatedRespStr))
                                            # before removing from dict
                                            logger.info(
                                                'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: response dictionary before removing [{}]'.format(
                                                    "9", resp['channelId'], resp['internalTransactionId'],
                                                    resp['spanId'], resp['traceId'], resp['requestType'], Dict))

                                            # Removing payloads from targetSystem dict
                                            Dict.pop('billingRespPayload', None)
                                            Dict.pop('ratingRespPayload', None)
                                            Dict.pop('mediationRespPayload', None)
                                            print("Dict:::BAASRespDecisionTbl::", Dict)

                                            # After removing from dict
                                            logger.info(
                                                'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: response dictionary after removing [{}]'.format(
                                                    "10", resp['channelId'], resp['internalTransactionId'],
                                                    resp['spanId'], resp['traceId'], resp['requestType'], Dict))

                                            workflow = Dict['workflow']
                                            if 'billing' in Dict:
                                                workflow = workflow + "_" + Dict['billing']
                                            else:
                                                workflow = workflow + "_" + "NA"
                                            if 'mediation' in Dict:
                                                workflow = workflow + "_" + Dict['mediation']
                                            else:
                                                workflow = workflow + "_" + "NA"
                                            if 'rating' in Dict:
                                                workflow = workflow + "_" + Dict['rating']
                                            else:
                                                workflow = workflow + "_" + "NA"

                                            print("concatinated workflow:::", workflow)

                                            BAASRespDecisionTbl = BAASResponseDecissionTable_tbl.query(
                                                KeyConditionExpression=Key('id').eq(workflow)
                                            )
                                            print("BAASRespDecisionTbl json data", BAASRespDecisionTbl)
                                            if BAASRespDecisionTbl['Items']:
                                                respKey = BAASRespDecisionTbl['Items'][0]['respKey']
                                                print("respKey from BAASRespDecisionTbl", respKey)
                                                # decision key from decision table
                                                logger.info(
                                                    'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: response decision key from decision table [{}]'.format(
                                                        "11", resp['channelId'], resp['internalTransactionId'],
                                                        resp['spanId'], resp['traceId'], resp['requestType'], respKey))

                                                BAASResponseTemplate = json.loads(
                                                    BAASResponseTemplate_tbl.get_item(Key={"respKey": respKey})['Item'][
                                                        'respTemplate'])
                                                print("BAASResponseTemplate::::", BAASResponseTemplate)
                                                # response template  from dynamo db
                                                logger.info(
                                                    'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: response template  from dynamo db [{}]'.format(
                                                        "12", resp['channelId'], resp['internalTransactionId'],
                                                        resp['spanId'], resp['traceId'], resp['requestType'],
                                                        BAASResponseTemplate))

                                                if BAASResponseTemplate:
                                                    # Replacing header from BAASResponseTemplate with resp values
                                                    if Dict['workflow'] == 'createPayment':
                                                        payment_fields = json.loads(resp['billingRespPayload'])
                                                        message['paymentProfileId'] = payment_fields['paymentProfileId']
                                                        message['paymentId'] = payment_fields['paymentId']
                                                    elif Dict['workflow'] == 'createProformaInvoice' or Dict[
                                                        'workflow'] == 'createInterimInvoice' or Dict[
                                                        'workflow'] == 'createHistoricInvoice' or Dict[
                                                        'workflow'] == 'createUnbilledUsage':
                                                        billing_fields = json.loads(resp['billingRespPayload'])
                                                        message['billingAccountNumber'] = billing_fields[
                                                            'billingAccountNumber']
                                                        message['companyName'] = billing_fields['companyName']
                                                        message['invoiceNumber'] = billing_fields['invoiceNumber']
                                                        message['invoiceDate'] = billing_fields['invoiceDate']
                                                        message['fileName'] = billing_fields['fileName']
                                                        message['bucketName'] = billing_fields['bucketName']
                                                    header['spanId'] = resp['spanId']
                                                    header['traceId'] = resp['traceId']
                                                    header['channelId'] = resp['channelId']
                                                    header['internalTransactionId'] = resp['internalTransactionId']
                                                    print("header template", header)
                                                    message['requestSubmittedOn'] = resp['requestProcessingStartTime']
                                                    message['requestProcessedOn'] = str(currentTime)
                                                    message['status'] = BAASResponseTemplate['message']['status']
                                                    print("message template", message)
                                                    if concatinatedRespStr is not None and concatinatedRespStr != '':
                                                        message['errorDetails'] = concatinatedRespStr
                                                        message['errorCode'] = BAASResponseTemplate['message'][
                                                            'errorCode']
                                                        message['errorMessage'] = BAASResponseTemplate['message'][
                                                            'errorMessage']
                                                        print("message template with error details", message)
                                                    BAASResponseTemplate.update({'header': header, 'message': message})

                                                    # Sending notification
                                                    # sendVar = sendNotification(BAASResponseTemplate,resp,BaasTransactionsInflight_tbl,BaasCallbackConfig_tbl,logger,'false',BaasTransactions_success_tbl,BaasTransactions_failure_tbl,BaasTransactions_rejected_tbl)
                                                    sendVar = sendNotification(BAASResponseTemplate, resp,
                                                                               BaasTransactionsInflight_tbl,
                                                                               BaasCallbackConfig_tbl, logger, 'false',
                                                                               BaasTransactions_tbl)
                                                else:
                                                    print("BAASResponseTemplate is empty")
                                            else:
                                                print("BAASRespDecisionTbl is empty with Dict conditions")
                                                BAASResponseTemplate = json.loads(BAASResponseTemplate_tbl.get_item(
                                                    Key={"respKey": resp['requestType'] + '_DEF_DEF_DEF'})['Item'][
                                                                                      'respTemplate'])
                                                if BAASResponseTemplate:
                                                    # Replacing header from BAASResponseTemplate with resp values
                                                    header['spanId'] = resp['spanId']
                                                    header['traceId'] = resp['traceId']
                                                    header['channelId'] = resp['channelId']
                                                    header['internalTransactionId'] = resp['internalTransactionId']
                                                    print("header template", header)
                                                    message['requestSubmittedOn'] = resp['requestProcessingStartTime']
                                                    message['requestProcessedOn'] = str(currentTime)
                                                    message['status'] = BAASResponseTemplate['message']['status']
                                                    print("message template", message)
                                                    if concatinatedRespStr is not None and concatinatedRespStr != '':
                                                        message['errorDetails'] = concatinatedRespStr
                                                        message['errorCode'] = BAASResponseTemplate['message'][
                                                            'errorCode']
                                                        message['errorMessage'] = BAASResponseTemplate['message'][
                                                            'errorMessage']
                                                        print("message template with error details", message)
                                                    BAASResponseTemplate.update({'header': header, 'message': message})

                                                    # Sending notification
                                                    sendVar = sendNotification(BAASResponseTemplate, resp,
                                                                               BaasTransactionsInflight_tbl,
                                                                               BaasCallbackConfig_tbl, logger, 'false',
                                                                               BaasTransactions_tbl)

                                        elif isFallout == 'true' and None in Dict.values():
                                            print("inside isfallout elif")
                                            # fall out case
                                            logger.info(
                                                'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: [{}]'.format(
                                                    "9", resp['channelId'], resp['internalTransactionId'],
                                                    resp['spanId'], resp['traceId'], resp['requestType'],
                                                    "order fall out"))
                                            BAASResponseTemplate = json.loads(BAASResponseTemplate_tbl.get_item(
                                                Key={"respKey": resp['requestType'] + '_DEF_DEF_DEF'})['Item'][
                                                                                  'respTemplate'])
                                            if BAASResponseTemplate:
                                                # Replacing header from BAASResponseTemplate with resp values
                                                header['spanId'] = resp['spanId']
                                                header['traceId'] = resp['traceId']
                                                header['channelId'] = resp['channelId']
                                                header['internalTransactionId'] = resp['internalTransactionId']
                                                print("header template", header)
                                                message['requestSubmittedOn'] = resp['requestProcessingStartTime']
                                                message['requestProcessedOn'] = str(currentTime)
                                                message['status'] = BAASResponseTemplate['message']['status']
                                                print("message template", message)

                                                message['errorDetails'] = 'Request Fallout'
                                                message['errorCode'] = BAASResponseTemplate['message']['errorCode']
                                                message['errorMessage'] = BAASResponseTemplate['message'][
                                                    'errorMessage']
                                                print("message template with error details", message)
                                                BAASResponseTemplate.update({'header': header, 'message': message})

                                                # Sending notification
                                                sendVar = sendNotification(BAASResponseTemplate, resp,
                                                                           BaasTransactionsInflight_tbl,
                                                                           BaasCallbackConfig_tbl, logger, isFallout,
                                                                           BaasTransactions_tbl)
                                    else:
                                        print("requestType is empty")
                                else:
                                    print("internalTransactionId is empty")
                            except KeyError as error:
                                print("Inside Exception")
                                updateLockStatus(resp, 'false', BaasTransactionsInflight_tbl)
                                logger.exception("message: the error occured due to " + str(error))
                    else:
                        print("keys are missing in resp")
                    header.clear()
                    message.clear()
                    # getRowExist = BaasTransactionsInflight_tbl.get_item(Key={"internalTransactionId": resp['internalTransactionId']})
                    # if 'Item' in getRowExist:
                    print("sendVar", sendVar)
                    if sendVar == 'false':
                        updateLockStatus(resp, 'false', BaasTransactionsInflight_tbl)
                    count = count + 1
                    print("count", count)
            else:
                print("BaasTransactionsInflight table has no records with notificationSentStatus as false")

        return {
            'statusCode': 200,
            'body': json.dumps('Notification process has been completed successfully..')
        }
    except Exception as error:
        logger.exception("message: the error occured due to " + str(error))
def createDictionary(targetSystemsArr, requestType, resp):
    Dict = {}
    Dict['workflow'] = requestType
    for targetSystem in targetSystemsArr:
        targetRespCode = targetSystem + 'RespStatus'
        targetRespPayload = targetSystem + 'RespPayload'
        if targetRespCode in resp:
            transactionRespStatus = resp[targetRespCode]
            print("transactionRespStatus", transactionRespStatus)
            if transactionRespStatus is not None and transactionRespStatus != '':
                print('transactionRespStatus=====', transactionRespStatus)
                Dict[targetSystem] = str(transactionRespStatus)
            else:
                Dict[targetSystem] = None
        else:
            Dict[targetSystem] = None
        if targetRespPayload in resp:
            print("targetRespPayload::::::::", targetRespPayload)
            transactionRespPayload = resp[targetRespPayload]
            print("transactionRespPayload::::::", transactionRespPayload)
            if transactionRespPayload is not None and transactionRespPayload != '':
                Dict[targetRespPayload] = transactionRespPayload
                print("Dict:::::", Dict)
    print("TargetSystem Dict:", Dict)
    return Dict
def sendNotification(BAASResponseTemplate, resp, BaasTransactionsInflight_tbl, BaasCallbackConfig_tbl, logger,
                     isFallout, BaasTransactions_tbl):
    sendVariable = 'false'
    # response template  from dynamo db
    logger.info(
        'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: payload to be dispatched for notification [{}]'.format(
            "13", resp['channelId'], resp['internalTransactionId'], resp['spanId'], resp['traceId'],
            resp['requestType'], BAASResponseTemplate))
    partner_id_item = {}
    billingRespPayload = None
    ratingRespPayload = None
    mediationRespPayload = None
    billingRespStatus = None
    ratingRespStatus = None
    mediationRespStatus = None
    billingRespTime = None
    ratingRespTime = None
    mediationRespTime = None

    if 'billingRespPayload' in resp:
        billingRespPayload = resp['billingRespPayload']
    if 'ratingRespPayload' in resp:
        ratingRespPayload = resp['ratingRespPayload']
    if 'mediationRespPayload' in resp:
        mediationRespPayload = resp['mediationRespPayload']

    if 'billingRespStatus' in resp:
        billingRespStatus = resp['billingRespStatus']
    if 'ratingRespStatus' in resp:
        ratingRespStatus = resp['ratingRespStatus']
    if 'mediationRespStatus' in resp:
        mediationRespStatus = resp['mediationRespStatus']

    if 'billingRespTime' in resp:
        billingRespTime = resp['billingRespTime']
    if 'ratingRespTime' in resp:
        ratingRespTime = resp['ratingRespTime']
    if 'mediationRespTime' in resp:
        mediationRespTime = resp['mediationRespTime']

    if resp['partnerId']:
        partner_id_item = BaasCallbackConfig_tbl.get_item(Key={"partnerId": resp['partnerId']})

    if 'Item' in partner_id_item:
        PartnerCallbackEndpoint = BaasCallbackConfig_tbl.get_item(Key={"partnerId": resp['partnerId']})['Item'][
            'endpoint']
        if PartnerCallbackEndpoint:
            logger.info(
                'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: call back url for posting the message [{}]'.format(
                    "14", resp['channelId'], resp['internalTransactionId'], resp['spanId'], resp['traceId'],
                    resp['requestType'], PartnerCallbackEndpoint))
            baas_status = BAASResponseTemplate['message']['status']
            print("baas_status", baas_status)
            # CallBackresponse = requests.post(PartnerCallbackEndpoint, data=BAASResponseTemplate, verify=False)
            if baas_status == 'Success':
                CallBackresponse = requests.post(PartnerCallbackEndpoint, json=BAASResponseTemplate, verify=False)
            # response template  from dynamo db
            logger.info(
                'Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}]'.format(
                    "15", resp['channelId'], resp['internalTransactionId'], resp['spanId'], resp['traceId'],
                    resp['requestType']))
            # if CallBackresponse.status_code == 200:
            # baas_status = BAASResponseTemplate['message']['status']
            # print("baas_status",baas_status)
            if isFallout == 'true':
                # notificationSentStatus = 'true'
                print("inside update isFallout")
                notificationSentStatus = 'false'
                updatebaasTrans_failure_fallout = BaasTransactions_tbl.put_item(
                    Item={
                        'internalTransactionId': resp['internalTransactionId'],
                        'requestPayload': resp['requestPayload'],
                        'requestTime': resp['requestTime'],
                        'requestProcessingStartTime': resp['requestProcessingStartTime'],
                        'spanId': resp['spanId'],
                        'traceId': resp['traceId'],
                        'requestType': resp['requestType'],
                        'channelId': resp['channelId'],
                        'partnerId': resp['partnerId'],
                        'topicName': resp['topicName'],
                        'notificationSent': notificationSentStatus,
                        'overallTransactionStatus': 'Fallout',
                        'lockStatus': 'false',
                        'billingRespPayload': billingRespPayload,
                        'ratingRespPayload': ratingRespPayload,
                        'mediationRespPayload': mediationRespPayload,
                        'billingRespStatus': billingRespStatus,
                        'ratingRespStatus': ratingRespStatus,
                        'mediationRespStatus': mediationRespStatus,
                        'billingRespTime': billingRespTime,
                        'ratingRespTime': ratingRespTime,
                        'mediationRespTime': mediationRespTime
                    })
                if updatebaasTrans_failure_fallout:
                    BaasTransactionsInflight_tbl.delete_item(
                        Key={
                            'internalTransactionId': resp['internalTransactionId']
                        }
                    )
                    sendVariable = 'true'
            elif baas_status == 'Success':
                notificationSentStatus = 'true'
                updatebaasTrans_success = BaasTransactions_tbl.put_item(
                    Item={
                        'internalTransactionId': resp['internalTransactionId'],
                        'requestPayload': resp['requestPayload'],
                        'requestTime': resp['requestTime'],
                        'requestProcessingStartTime': resp['requestProcessingStartTime'],
                        'spanId': resp['spanId'],
                        'traceId': resp['traceId'],
                        'requestType': resp['requestType'],
                        'channelId': resp['channelId'],
                        'partnerId': resp['partnerId'],
                        'topicName': resp['topicName'],
                        'notificationSent': notificationSentStatus,
                        'overallTransactionStatus': 'Completed',
                        'lockStatus': 'false',
                        'billingRespPayload': billingRespPayload,
                        'ratingRespPayload': ratingRespPayload,
                        'mediationRespPayload': mediationRespPayload,
                        'billingRespStatus': billingRespStatus,
                        'ratingRespStatus': ratingRespStatus,
                        'mediationRespStatus': mediationRespStatus,
                        'billingRespTime': billingRespTime,
                        'ratingRespTime': ratingRespTime,
                        'mediationRespTime': mediationRespTime
                    })
                if updatebaasTrans_success:
                    BaasTransactionsInflight_tbl.delete_item(
                        Key={
                            'internalTransactionId': resp['internalTransactionId']
                        }
                    )
                    sendVariable = 'true'
            elif baas_status == 'Failure':
                # notificationSentStatus = 'true'
                notificationSentStatus = 'false'
                updatebaasTrans_failure = BaasTransactions_tbl.put_item(
                    Item={
                        'internalTransactionId': resp['internalTransactionId'],
                        'requestPayload': resp['requestPayload'],
                        'requestTime': resp['requestTime'],
                        'requestProcessingStartTime': resp['requestProcessingStartTime'],
                        'spanId': resp['spanId'],
                        'traceId': resp['traceId'],
                        'requestType': resp['requestType'],
                        'channelId': resp['channelId'],
                        'partnerId': resp['partnerId'],
                        'topicName': resp['topicName'],
                        'notificationSent': notificationSentStatus,
                        'overallTransactionStatus': 'Failed',
                        'lockStatus': 'false',
                        'billingRespPayload': billingRespPayload,
                        'ratingRespPayload': ratingRespPayload,
                        'mediationRespPayload': mediationRespPayload,
                        'billingRespStatus': billingRespStatus,
                        'ratingRespStatus': ratingRespStatus,
                        'mediationRespStatus': mediationRespStatus,
                        'billingRespTime': billingRespTime,
                        'ratingRespTime': ratingRespTime,
                        'mediationRespTime': mediationRespTime
                    })
                if updatebaasTrans_failure:
                    BaasTransactionsInflight_tbl.delete_item(
                        Key={
                            'internalTransactionId': resp['internalTransactionId']
                        }
                    )
                    sendVariable = 'true'
            # else:
            #     print("Endpoint is not correct/valid")
        else:
            print("PartnerCallbackEndpoint is empty")
    else:
        print("inside rejected")
        notificationSentStatus = 'rejected'
        updatebaasTrans_rejected = BaasTransactions_tbl.put_item(
            Item={
                'internalTransactionId': resp['internalTransactionId'],
                'requestPayload': resp['requestPayload'],
                'requestTime': resp['requestTime'],
                'requestProcessingStartTime': resp['requestProcessingStartTime'],
                'spanId': resp['spanId'],
                'traceId': resp['traceId'],
                'requestType': resp['requestType'],
                'channelId': resp['channelId'],
                'partnerId': resp['partnerId'],
                'topicName': resp['topicName'],
                'notificationSent': notificationSentStatus,
                'overallTransactionStatus': 'Notification Failed',
                'lockStatus': 'false',
                'billingRespPayload': billingRespPayload,
                'ratingRespPayload': ratingRespPayload,
                'mediationRespPayload': mediationRespPayload,
                'billingRespStatus': billingRespStatus,
                'ratingRespStatus': ratingRespStatus,
                'mediationRespStatus': mediationRespStatus,
                'billingRespTime': billingRespTime,
                'ratingRespTime': ratingRespTime,
                'mediationRespTime': mediationRespTime
            })
        if updatebaasTrans_rejected:
            BaasTransactionsInflight_tbl.delete_item(
                Key={
                    'internalTransactionId': resp['internalTransactionId']
                }
            )
            sendVariable = 'true'

    return sendVariable
def getTargetSystem(requestType):
    dynamodb_client = boto3.client("dynamodb", region_name="eu-west-2")
    trgetSystemsResp = dynamodb_client.get_item(TableName='BAASTargetSystems', Key={'workflow': {'S': requestType}})
    print("trgetSystemsResp", trgetSystemsResp)
    if 'Item' in trgetSystemsResp:
        targetSystems = trgetSystemsResp['Item'].get('targetSystems')
        targetSystemsArr = targetSystems.get('S').split(',')
        print("targetSystemsArr::::::", targetSystemsArr)
        return targetSystemsArr
    else:
        print("Target system is empty/invalid in BAASTargetSystems table")
def updateLockStatus(resp, status, BaasTransactionsInflight_tbl):
    BaasTransactionsInflight_tbl.update_item(
        Key={'internalTransactionId': resp['internalTransactionId']},
        UpdateExpression="set lockStatus = :lockStatus",
        ExpressionAttributeValues={
            ':lockStatus': status
        },
        ReturnValues="UPDATED_NEW"
    )