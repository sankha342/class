import json
import unittest
from unittest.mock import Mock
import boto3
import PartnerRequestInjectionFn
from PartnerRequestInjectionFn import PartnerRequestInjectionFn_handler
from time import time
from moto import mock_dynamodb2, mock_dynamodb
from datetime import datetime
import uuid
from boto3.dynamodb.conditions import Attr

returnStatement = {'statusCode': 200, 'body': '{\n    "header": \n        {\n            "spanId": "f36d9dd9-256c-4ca0-bde3-4e0b47b0c689",\n            "channelId": "Online",\n            "traceId": "266266ac-7a44-439d-896a-fdb9e646eae8",\n            "internalTransactionId": "408fc11912fd4706a63af16d4e13a7ba1655795553391"\n        }\n    ,\n    "status": "Success"\n}'}
event = {'requestContext': {'elb': {'targetGroupArn': 'arn:aws:elasticloadbalancing:us-west-2:792727994513:targetgroup/dish-wireless-baas-msg-producer/96de8a7f54298ee0'}}, 'httpMethod': 'POST', 'path': '/mno/subscribers/produceMessage', 'queryStringParameters': {}, 'headers': {'accept': '*/*', 'accept-encoding': 'gzip, deflate, br', 'authorization': 'Bearer f74AK9cIUH0vPXCXNlMoXbMJoaur', 'channelid': 'Online', 'clientid': '1234577', 'connection': 'close', 'content-length': '3884', 'content-type': 'application/json', 'host': 'dish.wireless-mno-intg-i.aws.dishcloud.io', 'partnerid': 'partner1', 'requesttype': 'createSubscription', 'spanid': 'f36d9dd9-256c-4ca0-bde3-4e0b47b0c689', 'topicname': '5g.bss.baas.createsubscription.am.1.0', 'traceid': '266266ac-7a44-439d-896a-fdb9e646eae8', 'traceparent': '00-153ac23e85ab45a246361e5cbb428b05-eff33d245aa78c46-01', 'tracestate': '5b40908c-6a8f088b@dt=fw4;3;98fb40a;3743;3;0;0;150;37c3;2h01;3h098fb40a;4h3743;5h01;7heff33d245aa78c46', 'user-agent': 'python-requests/2.27.1', 'x-amzn-trace-id': 'Self=1-62b09189-01e7915576364c703f8b897c;Root=1-62b09189-49b5499f537d77562210cd34', 'x-client-id': 'd001', 'x-correlation-id': 'c001', 'x-dynatrace': 'FW4;1787758731;3;160412682;14147;3;1530957964;336;9b58;2h01;3h098fb40a;4h3743;5h01;6h153ac23e85ab45a246361e5cbb428b05;7heff33d245aa78c46', 'x-dynatrace-application': 'v=2;appId=;cookieDomain=dish.com;rid=-533357996;rpid=-1088041672;en=unhwf5yr', 'x-dynatrace-requeststate': 'agentId=0x4afe87b6098fb40a&pathDepth=1', 'x-enforce-captcha': 'yes', 'x-forwarded-for': '103.88.216.55, 35.227.131.190, 10.161.240.27, 10.208.155.218:46586', 'x-forwarded-port': '443', 'x-forwarded-proto': 'https', 'x-originating-ip': '103.88.216.55', 'x-ruxit-forwarded-for': '103.88.216.55', 'x-transaction-id': 'b1a1b8fc-4346-43e7-8a55-7760b63e49f9'}, 'body': '\n            {"subscriber":{"subscriberId":"ck-Subscriber-0-95aba03d-006c-4048-b84a-1b677d2aece6","attr":{"MasterAccount":"ck-MasterAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5","BillingAccount":"ck-BillingAccount-762-024f66e7-9bd7-40f2-ace1-e6a6b90a7eb5","WholesalePlanId":"DISH-Plan002"},"firstName":"Udaya","lastName":"Shanker","activeDt":"2022-05-02T18:00:00Z","subscriptionAddresses":[{"addressLine1":"52-A-1","addressLine2":"St Mount StreetA-1","addressLine3":"St Mount StreetB-1","city":"Ann Arbor","state":"MI","country":"USA","postalCode":"12345","addressType":"AEnd"}],"subscriptions":[{"subscriptionId":"ck-SubscriptionId-0-95aba03d-006c-4048-b84a-1b677d2aece6","networkName":"DISH","billingCycle":{"billingCycleId":200,"dateOffset":30,"immediateChange":true},"offers":[{"offerId":"123","allowanceDetails":[{"allowanceName":"Subscriber - Data Allowance","allowanceReferenceId":"ef5a3a83-ce87-405d-b624-3db85efdb368","allowanceInstanceId":"07f23b4c-bc00-11ec-aa10-0242ac110002","allowanceType":"DDON","externalName":"Data_Allowance","allowanceGrant":5,"unitOfMeasure":"MB","priority":1,"cycleBased":true,"rollOver":true,"allowancePeriodicity":"MONTH","allowancePeriodicityUnits":1,"policies":[{"policyReferenceId":"9e2c7935-46f7-446d-9d5d-bd469886c64f","policyInstanceId":"07f2b07d-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Notify","externalName":"Policy_Data_Notify2","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"NOTIFY","level":75},{"policyReferenceId":"9e2c7935-46f7-446d-9d5d-bd469886c64f","policyInstanceId":"07f2b07e-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Notify","externalName":"Policy_Data_Notify3","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"NOTIFY","level":50},{"policyReferenceId":"9e2c7935-46f7-446d-9d5d-bd469886c64f","policyInstanceId":"07f2b07f-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Notify","externalName":"Policy_Data_Notify1","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"NOTIFY","level":100},{"policyReferenceId":"f995d6f9-12e1-4ca9-9463-bb87454c4c62","policyInstanceId":"07f2b080-bc00-11ec-aa10-0242ac110002","policyName":"Subscriber - Policy Cap","externalName":"Policy_Data_Cap","unitOfMeasure":"MB","measurementType":"PERCENTAGE","action":"CAP","level":100}]}]},{"offerId":"123","rate":2000,"allowanceDetails":[{"allowanceName":"Subscriber - Data Allowance","allowanceReferenceId":"allowance-ref-id-1","allowanceInstanceId":"allowance-instance-id-1","allowanceType":"DDON","externalName":"One Time Data Bucket (Expires)","allowanceGrant":100,"unitOfMeasure":"MB","priority":1,"cycleBased":false,"rollOver":false,"allowancePeriodicityUnits":1,"allowancePeriodicity":"MONTH","policies":[{"policyReferenceId":"policy-ref-id-1","policyInstanceId":"policy-inst-id-1","policyName":"policy-name-1","externalName":"Notification 1st Level","action":"NOTIFY","level":33,"unitOfMeasure":"MB","measurementType":"PERCENTAGE"},{"policyReferenceId":"policy-ref-id-2","policyInstanceId":"policy-inst-id-2","policyName":"policy-name-2","externalName":"Notification 2nd Level","action":"NOTIFY","level":67,"unitOfMeasure":"MB","measurementType":"PERCENTAGE"},{"policyReferenceId":"policy-ref-id-3","policyInstanceId":"policy-inst-id-3","policyName":"policy-name-3","externalName":"Notification 3rd Level","action":"NOTIFY","level":90,"unitOfMeasure":"MB","measurementType":"PERCENTAGE"},{"policyReferenceId":"policy-ref-id-4","policyInstanceId":"policy-inst-id-4","policyName":"policy-name-4","externalName":"Cap Level","action":"CAP","level":100,"unitOfMeasure":"MB","measurementType":"PERCENTAGE"}]}]}],"subscriptionAttributes":[{"gpsi":"231291843531","supi":"655146594492566"}]}]},"header":{"spanId":"f36d9dd9-256c-4ca0-bde3-4e0b47b0c689","channelId":"Online","traceId":"266266ac-7a44-439d-896a-fdb9e646eae8","partnerId":"partner1"}}\n        ', 'isBase64Encoded': False}

class TestLambdaFunction(unittest.TestCase):
    @mock_dynamodb2
    def test_PartnerRequestInjectionFn_handler(self):
        boto3.setup_default_session()
        client = boto3.client("dynamodb", region_name='us-west-2')
        client.create_table(
            TableName="BaasRequestQueue",
            KeySchema=[
                {"AttributeName": "internalTransactionId", "KeyType": "HASH"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "internalTransactionId", "AttributeType": "S"},
            ],
            ProvisionedThroughput={
                'ReadCapacityUnits': 50,
                'WriteCapacityUnits': 50
            }
        )
        response = PartnerRequestInjectionFn.PartnerRequestInjectionFn_handler(event, {})
        print("response::::", response)
        returnStatement['body'] = response['body']
        self.assertEqual(returnStatement, response)

if __name__ == '__main__':
    unittest.main()