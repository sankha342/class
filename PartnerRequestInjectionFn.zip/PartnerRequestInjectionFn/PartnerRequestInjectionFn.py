import boto3
import urllib3
import time
import json
import logging
import uuid
from datetime import datetime
from time import time

# Logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def PartnerRequestInjectionFn_handler(event, context):
    try:
        # Added urllib3 to ignore request warning
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # Using DynamoDB Client and Resource
        # dbclient = boto3.client('dynamodb')

        baasRequestQueue_tbl = boto3.resource('dynamodb', region_name="us-west-2").Table('BaasRequestQueue')

        # datetime operations for internalTransId and requestTime
        dt = datetime.now()
        format = "%d-%m-%Y %H:%M:%S"
        currentTime = dt.strftime(format)   # format datetime using strftime() 
        # now = int(time()) + 1
        now = round(time() * 1000) + 1
        internalTransId = uuid.uuid4().hex + str(now)
        print("internaltransid type", type(internalTransId))
        # Getting header details from event and storing them in variables
        apigee_body = json.loads(event['body'])
        apigee_header = apigee_body["header"]
        spanId = apigee_body["header"]["spanId"]
        channelId = apigee_body["header"]["channelId"]
        traceId = apigee_body["header"]["traceId"]
        partnerId = apigee_body["header"]["partnerId"]
        requestPayload = event["body"]
        requestTime = str(currentTime)
        requestType = event["headers"]["requesttype"]
        topicName = event["headers"]["topicname"]
        
        # Getting the payload from event and adding headers to it
        addInternalTransactionId = {
            'internalTransactionId': internalTransId
        }
        addInternalTransactionId.update(apigee_header)
        apigee_header_dict = {'header':addInternalTransactionId}
        apigee_body.update(apigee_header_dict)
        apigee_body_str = json.dumps(apigee_body)
        final_apigee_body = json.loads(apigee_body_str)    
        print("final_apigee_body:::::", final_apigee_body)
        
        # logger from header
        logger.info('Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: request received [{}]'.format(
            "1", channelId, internalTransId, spanId, traceId, requestType, requestPayload ))
    
        # Insert into BaasRequestQueue table by passing all the required variables
        updatebaasTrans = baasRequestQueue_tbl.put_item(
            Item = {
                'internalTransactionId': internalTransId,
                'requestPayload': requestPayload,
                'requestTime': requestTime,
                'spanId': spanId,
                'traceId': traceId,
                'requestType': requestType,
                'channelId': channelId,
                'partnerId': partnerId,
                'topicName': topicName,
                'notificationSent': 'false',
                'overallTransactionStatus': 'Queued',
                'lockStatus': 'false'
            })
        
        print("updatebaasTrans", updatebaasTrans)
        
        # Logging after inserting record in BaasRequestQueue table
        logger.info('Step number: [{}], channelId: [{}], internalTransactionId: [{}], spanId: [{}], traceId: [{}], requestType: [{}], message: [{}]'.format(
            "2", channelId, internalTransId, spanId, traceId, requestType, "Request queued to DynamoDB" ))
        
        return{
            "statusCode": 200,
            "body": json.dumps({"header": [{"spanId": spanId, "channelId": channelId, "traceId": traceId, "internalTransactionId": internalTransId}],"status": "Success"},indent=4).replace('[', '').replace(']', '')
            }

    except Exception as error:
        print("Inside Exception")
        logger.exception("message: the error occured due to "+str(error))
        return{
            "statusCode": 417,
            "body": json.dumps({"header": [{"spanId": spanId, "channelId": channelId, "traceId": traceId, "internalTransactionId": internalTransId}],"status": "Failure", "error": {"errorCode": "BAAS_INJ_ERROR", "errorMessage": "Request Injection Failed"}},indent=4).replace('[', '').replace(']', '')
            }
